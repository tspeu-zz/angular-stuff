import { JwtInterceptor } from './jwt-interceptor.service';

describe('JwtInterceptor', () => {
  it('should create an instance', () => {
    expect(new JwtInterceptor()).toBeTruthy();
  });
});
