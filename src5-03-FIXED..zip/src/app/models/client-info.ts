export class ClientInfo {
   countryCode: string;
   userCountryCode: string;
   isMobile: boolean;
}
