export class Link {
    text: string;
    active: number;
    disable: number;
    url?: string;
}
