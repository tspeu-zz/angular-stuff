import {Affiliate} from '../affiliate';

export class LoginResponse {
   token: string;
   affiliate: Affiliate;
}
