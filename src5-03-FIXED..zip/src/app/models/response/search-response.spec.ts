import { SearchResponse } from './search-response';

describe('SearchResponse', () => {
  it('should create an instance', () => {
    expect(new SearchResponse()).toBeTruthy();
  });
});
