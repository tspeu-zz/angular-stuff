import { ResponseBody } from './response-body';

describe('ResponseBody', () => {
  it('should create an instance', () => {
    expect(new ResponseBody()).toBeTruthy();
  });
});
