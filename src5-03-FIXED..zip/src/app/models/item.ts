export class Item {
   id: number;
   label: string;
   seoUrl: string;
   selected?: boolean;
   total?: number;
}
