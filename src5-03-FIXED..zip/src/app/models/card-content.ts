export class CardContent {
   image?: string;
   mainMessage?: string;
   secondaryMessage?: string;
   descriptionMessage?: string;
   isErrorCard = false;
   buttonLabel?: string;
}
