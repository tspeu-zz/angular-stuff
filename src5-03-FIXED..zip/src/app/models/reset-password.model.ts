export interface ResetPassword {

    password: string;
    confirmPassword: string;
    token: string;
}
