export class Icon {
    label: string;
    notificationNumber?: number;
    icon: string;
}
