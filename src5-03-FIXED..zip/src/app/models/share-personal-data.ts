import { InvoiceData } from './invoice-data';

export interface SharePersonalData {
    prefixCountry: string;
    invoiceData: InvoiceData;
}
