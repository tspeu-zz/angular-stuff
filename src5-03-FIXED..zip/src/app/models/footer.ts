export class Footer {
    icon: string;
    country?: string;
    copyright: string;
    year: number;
    business: string;
    right: string;
}
