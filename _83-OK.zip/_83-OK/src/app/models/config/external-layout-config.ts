export class ExternalLayoutConfig {
    title =  'Programa de <b>afiliados</b>';
    titleColor = '#f7f8fc';
    titlePosition = 'left';
    logoFooter = 'https://cdn.techtitute.com/techtitute/assets/logos/tech-universidad-tecnologica-white.svg';
    isActiveLogoFooter = false;
}
