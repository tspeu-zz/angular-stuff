import { ExternalLayoutConfig } from './external-layout-config';

describe('ExternalLayout', () => {
  it('should create an instance', () => {
    expect(new ExternalLayoutConfig()).toBeTruthy();
  });
});
