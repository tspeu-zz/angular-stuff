export interface Register {
    email: string;
    name: string;
    surname: string;
    password: string;
    confirmPassword: string;
}
