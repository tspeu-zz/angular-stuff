import { InvoiceData } from './invoice-data';

describe('InvoiceData', () => {
  it('should create an instance', () => {
    expect(new InvoiceData()).toBeTruthy();
  });
});
