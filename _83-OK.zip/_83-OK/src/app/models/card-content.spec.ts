import { CardContent } from './card-content';

describe('CardContent', () => {
  it('should create an instance', () => {
    expect(new CardContent()).toBeTruthy();
  });
});
