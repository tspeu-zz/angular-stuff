import { Affiliate } from './affiliate';

describe('Affiliate', () => {
  it('should create an instance', () => {
    expect(new Affiliate()).toBeTruthy();
  });
});
