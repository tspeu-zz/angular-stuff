import { PersonalData } from './personal-data';

describe('PersonalData', () => {
  it('should create an instance', () => {
    expect(new PersonalData()).toBeTruthy();
  });
});
