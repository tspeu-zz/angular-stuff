export class NgSelectConfig {
   placeholder: string;
   bindValue = 'label';
   notFoundText = 'No se ecuentr';
}
