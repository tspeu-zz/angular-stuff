export class Course {
   title: string;
   url: string;
}
